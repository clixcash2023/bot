import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ParseMode
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram import types
import json

class Mensagem(StatesGroup):
    email = State()
    mensagem = State()

bot = Bot(token="SEU_TOKEN", parse_mode='HTML')
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

@dp.message_handler(commands='start')
async def iniciar(message: types.Message):
    """Painel de início do bot do Telegram"""

    with open('data/admins.json') as arquivo:
        admins = json.load(arquivo)

    for i in admins:
        if message.from_user.id == i['id_admin']:
            botoes = ['Painel de Admin']
            teclado = types.ReplyKeyboardMarkup(resize_keyboard=True)
            teclado.add(*botoes)
            break
        else:
            botoes = ['Escrever para o Suporte']
            teclado = types.ReplyKeyboardMarkup(resize_keyboard=True)
            teclado.add(*botoes)

    await message.answer(f'Bem-vindo', reply_markup=teclado)

@dp.message_handler(Text(equals='Escrever para o Suporte'))
async def obter_email(message: types.Message):
    """Pedir ao usuário para inserir um e-mail"""

    await Mensagem.email.set()
    await message.answer(f'Digite o e-mail')

@dp.message_handler(state=Mensagem.email)
async def salvar_email(message: types.Message, state: FSMContext):
    """Salvar o e-mail, pedir ao usuário para inserir uma mensagem"""
    async with state.proxy() as data:
        data['email'] = message.text
        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        flag = False
        for i in usuarios:
            if i['id'] == message.from_user.id:
                flag = True
                await message.answer(f'Você já enviou uma solicitação de suporte. Se deseja adicionar mais informações, apenas escreva no chat.')
                await state.finish()
                break

        if not flag:
            await Mensagem.mensagem.set()
            await message.answer(f'Digite a mensagem')

@dp.message_handler(state=Mensagem.mensagem)
async def processar_informacoes_de_contato(message: types.Message, state: FSMContext):
    """Salvar a mensagem inserida pelo usuário"""

    async with state.proxy() as data:
        data['mensagem'] = message.text
        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        if usuarios:
            flag = False

            for i in usuarios:
                if i["email"] == data["email"]:
                    i["mensagem"].append(f'<b>Para:</b> {data["mensagem"]}\n')
                    flag = True
                    break

            if not flag:
                usuarios.append({
                    "id": message.from_user.id,
                    "email": data['email'],
                    "mensagem": [f'<b>Para:</b> {data["mensagem"]}\n'],
                    "id_admin": None
                })

        else:
            usuarios.append({
                "id": message.from_user.id,
                "email": data['email'],
                "mensagem": [f'<b>Para:</b> {data["mensagem"]}\n'],
                "id_admin": None
            })

        with open(f'data/data.json', 'w') as arquivo:
            json.dump(usuarios, arquivo, indent=3, ensure_ascii=False)

        with open('data/admins.json') as arquivo2:
            admins = json.load(arquivo2)

        for i in admins:
            await bot.send_message(str(i['id_admin']), f'<b>Nova mensagem</b>\nde: {data["email"]}\n\n{data["mensagem"]}' )

        await message.answer(f'Mensagem recebida, aguarde.\n')
        await state.finish()

@dp.message_handler(Text(equals='Painel de Admin'))
async def painel_admin(message: types.Message):
    """Acessar o painel de administração"""

    botoes = ['Novas', 'Transferir', 'Excluir', 'Minhas Solicitações', 'Histórico de Mensagens', 'Conversar com Quem?', 'Instruções']
    teclado = types.ReplyKeyboardMarkup(resize_keyboard=True)
    teclado.add(*botoes)

    await message.answer(f'Selecione uma ação', reply_markup=teclado)

@dp.message_handler(Text(equals='Novas'))
async def novas(message: types.Message):
    """Mostrar novas mensagens"""

    with open('data/data.json') as arquivo:
        usuarios = json.load(arquivo)

    lista_de_mensagens = []

    for i in usuarios:
        if i['id_admin'] is None:
            lista_de_mensagens.append(i['email'])

    if lista_de_mensagens:
        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Pegar_novo_usuario") for j in lista_de_mensagens]
        teclado.add(*botoes)

        await bot.send_message(chat_id=message.chat.id, text='Escolha a mensagem:', reply_markup=teclado)
    else:
        await bot.send_message(chat_id=message.chat.id, text='Nenhuma mensagem nova')

@dp.message_handler(Text(equals='Transferir'))
async def transferir(message: types.Message):
    """Exibir uma lista de administradores para escolher para quem transferir o cliente"""

    with open('data/data.json') as arquivo:
        usuarios = json.load(arquivo)

    meus_usuarios = []
    for i in usuarios:
        if i["id_admin"] == message.chat.id:
            meus_usuarios.append(i['email'])
        else:
            continue

    if meus_usuarios:
        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Mudar_cliente") for j in meus_usuarios]
        teclado.add(*botoes)
        await bot.send_message(chat_id=message.chat.id, text='Escolha o usuário que deseja transferir para outro administrador', reply_markup=teclado)
    else:
        await message.answer('Você não tem conversas em andamento com os usuários')

@dp.message_handler(Text(equals='Excluir'))
async def remover(message: types.Message):
    """Exibir uma lista de clientes para encerrar o diálogo"""

    with open('data/data.json') as arquivo:
        usuarios = json.load(arquivo)

    meus_usuarios = []
    for i in usuarios:
        if i["id_admin"] == message.chat.id:
            meus_usuarios.append(i['email'])
        else:
            continue

    if meus_usuarios:
        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Deletar_chat") for j in meus_usuarios]
        teclado.add(*botoes)
        await bot.send_message(chat_id=message.chat.id, text='Escolha o usuário com o qual deseja encerrar o diálogo', reply_markup=teclado)
    else:
        await message.answer('Você não tem conversas em andamento com os usuários')

@dp.message_handler(Text(equals='Minhas Solicitações'))
async def minhas_solicitacoes(message: types.Message):
    """Exibir uma lista de diálogos iniciados"""

    with open('data/data.json') as arquivo:
        usuarios = json.load(arquivo)

    meus_usuarios = []
    for i in usuarios:
        if i["id_admin"] == message.chat.id:
            meus_usuarios.append(i['email'])
        else:
            continue

    if meus_usuarios:
        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Editar_chat") for j in meus_usuarios]
        teclado.add(*botoes)
        await bot.send_message(chat_id=message.chat.id, text='Escolha o usuário para o qual deseja mudar', reply_markup=teclado)
    else:
        await message.answer('Você não tem conversas em andamento com os usuários')

@dp.message_handler(Text(equals='Histórico de Mensagens'))
async def historico(message: types.Message):
    """Exibir uma lista de diálogos iniciados para mostrar o histórico de mensagens"""

    with open('data/data.json') as arquivo:
        usuarios = json.load(arquivo)

    meus_usuarios = []
    for i in usuarios:
        if i["id_admin"] == message.chat.id:
            meus_usuarios.append(i['email'])
        else:
            continue

    if meus_usuarios:
        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Mostrar_meu_historico") for j in meus_usuarios]
        teclado.add(*botoes)
        await bot.send_message(chat_id=message.chat.id, text='Escolha o usuário para ver o histórico de mensagens', reply_markup=teclado)
    else:
        await message.answer('Você não tem conversas em andamento com os usuários')

@dp.message_handler(Text(equals='Conversar com Quem?'))
async def verificar_o_diálogo(message: types.Message):
    """Verificar quem receberá a mensagem se escrevermos no bot do chat"""

    with open('data/plaseholders.json') as arquivo2:
        placeholders = json.load(arquivo2)

        for j in placeholders:
            if j['id_admin'] == message.chat.id:

                with open('data/data.json') as arquivo:
                    usuarios = json.load(arquivo)

                if usuarios:

                    flag = False
                    for i in usuarios:
                        if i['id'] == j['id']:
                            flag = True
                            await message.answer(f'A mensagem que você enviar será recebida pelo usuário <b>"{i["email"]}"</b>')

                    if not flag:
                        await message.answer(f'Nenhum diálogo selecionado. Use a guia <b>"Minhas Solicitações"</b> para selecionar um diálogo')

                else:
                    await message.answer(f'Sem diálogos ativos')

@dp.message_handler(Text(equals='Instruções'))
async def instrucoes(message: types.Message):
    await message.answer(f'Na guia <b>"Novas"</b>, você verá as mensagens de entrada que ainda não foram visualizadas por nenhum administrador. Para iniciar um diálogo com o usuário, basta clicar no e-mail do remetente.\n\nDepois de clicar no e-mail do remetente na guia <b>"Novas"</b>, você pode transferir o usuário para outro administrador, clicando na guia <b>"Transferir"</b>.\n\nNa guia <b>"Excluir"</b>, você pode encerrar o diálogo com o usuário.\n\nNa guia <b>"Minhas Solicitações"</b>, você verá todos os diálogos que você iniciou como administrador. Você pode alternar entre eles.\n<b>Importante</b>: Preste atenção em qual dos usuários receberá a mensagem. Para isso, clique na guia <b>"Conversar com Quem?"</b>.\n\nTambém é possível verificar o histórico de mensagens com o usuário. Para isso, clique em <b>"História de Mensagens"</b>. Depois que a conversa for excluída, o histórico das mensagens também será excluído.')

async def lidar_com_callback(query: types.CallbackQuery):
    """Aceitar dados de callback_data"""

    await query.message.edit_reply_markup()

    if "Pegar_novo_usuario" in query.data:
        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        email = query.data.replace('Pegar_novo_usuario', '')

        with open('data/admins.json') as arquivo:
            admins = json.load(arquivo)

        lista_de_admins = []
        for i in admins:
            if i['id_admin'] == query.message.chat.id:
                meu_nome = i['nome']
            else:
                lista_de_admins.append(i['id_admin'])

        for a in lista_de_admins:
            await bot.send_message(chat_id= a, text=f'O diálogo com o usuário <b>{email}</b> foi pego pelo administrador <b>{meu_nome}</b>')

        for i in usuarios:
            if i['email'] == email:
                i['id_admin'] = query.message.chat.id

                with open('data/plaseholders.json') as arquivo2:
                    placeholders = json.load(arquivo2)

                for j in placeholders:
                    if j['id_admin'] == query.message.chat.id:
                        j['id'] = i['id']

                with open(f'data/plaseholders.json', 'w') as arquivo3:
                    json.dump(placeholders, arquivo3, indent=3, ensure_ascii=False)

                with open(f'data/data.json', 'w') as arquivo3:
                    json.dump(usuarios, arquivo3, indent=3, ensure_ascii=False)

                mensagem = "".join(i['mensagem'])

                if len(mensagem) > 4000:
                    for x in range(0, len(mensagem), 4000):
                        await query.message.answer(f'De: <b>{i["email"]}</b>\n\n{mensagem[x:x+4000]}')
                else:
                    await query.message.answer(f'De: <b>{i["email"]}</b>\n\n{mensagem}')

                await query.message.answer(f'Digite uma resposta e o usuário <b>"{i["email"]}"</b> receberá a sua mensagem\n⏬⏬⏬')

    if  "Transferir_cliente" in query.data:
        mensagem = query.data.replace('Transferir_cliente', '')

        with open('data/admins.json') as arquivo:
            admins = json.load(arquivo)

        lista_de_admins = []
        for i in admins:
            if i['id_admin'] == query.message.chat.id:
                continue
            else:
                lista_de_admins.append(i['nome'])

        teclado = InlineKeyboardMarkup(row_width=1)
        botoes = [InlineKeyboardButton((str(j)), callback_data=str(j) + "Transferir_admin" + " " + mensagem) for j in lista_de_admins]
        teclado.add(*botoes)

        await bot.send_message(chat_id=query.message.chat.id, text=f'Escolha um administrador para transferir o usuário <b>{mensagem}</b>', reply_markup=teclado)

    if  "Transferir_admin" in query.data:
        mensagem = query.data.split(' ')
        email = mensagem[-1]
        nome = mensagem[0].replace('Transferir_admin', '')

        with open('data/admins.json') as arquivo:
            admins = json.load(arquivo)

        for k in admins:
            if nome == k['nome']:
                id_admin = k['id_admin']

            if k['id_admin'] == query.message.chat.id:
                meu_nome = k['nome']

        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        for i in usuarios:
            if i['email'] == email:
                i["id_admin"] = id_admin

                with open(f'data/data.json', 'w') as arquivo3:
                    json.dump(usuarios, arquivo3, indent=3, ensure_ascii=False)

                with open('data/plaseholders.json') as arquivo4:
                    placeholders = json.load(arquivo4)

                for j in placeholders:
                    if j['id_admin'] == query.message.chat.id and j['id']==i['id']:
                        j['id'] = None

                with open(f'data/plaseholders.json', 'w') as arquivo5:
                    json.dump(placeholders, arquivo5, indent=3, ensure_ascii=False)

        await bot.send_message(chat_id=query.message.chat.id, text=f'O usuário "<b>{email}</b>" foi transferido para o administrador <b>{nome}</b>')
        await bot.send_message(chat_id=id_admin, text=f'Você recebeu o usuário "<b>{email}</b>" do administrador {meu_nome}')

    if  "Deletar_chat" in query.data:
        mensagem = query.data.replace('Deletar_chat', '')

        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        p = 0
        for i in usuarios:
            p+=1
            if mensagem == i['email']:

                with open('data/plaseholders.json') as arquivo3:
                    placeholders = json.load(arquivo3)

                for j in placeholders:
                    if j['id_admin'] == query.message.chat.id and j['id'] == i['id']:
                        j['id'] = None

                with open(f'data/plaseholders.json', 'w') as arquivo4:
                    json.dump(placeholders, arquivo4, indent=3, ensure_ascii=False)

                usuarios.pop(p-1)

                with open(f'data/data.json', 'w') as arquivo2:
                    json.dump(usuarios, arquivo2, indent=3, ensure_ascii=False)

                await bot.send_message(chat_id=query.message.chat.id, text=f'O atendimento do usuário "<b>{i["email"]}</b>" foi encerrado')

    if  "Editar_chat" in query.data:
        mensagem = query.data.replace('Editar_chat', '')

        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        for i in usuarios:
            if i['email'] == mensagem:

                with open('data/plaseholders.json') as arquivo2:
                    placeholders = json.load(arquivo2)

                for j in placeholders:
                    if j['id_admin'] == query.message.chat.id:
                        j['id'] = i['id']

                with open(f'data/plaseholders.json', 'w') as arquivo3:
                    json.dump(placeholders, arquivo3, indent=3, ensure_ascii=False)

                await query.message.answer(f'Você mudou para o usuário <b>"{i["email"]}"</b>. Digite uma resposta e ele receberá a sua mensagem\n⏬⏬⏬')

    if  "Mostrar_meu_historico" in query.data:
        mensagem = query.data.replace('Mostrar_meu_historico', '')

        with open('data/data.json') as arquivo:
            usuarios = json.load(arquivo)

        for i in usuarios:
            if i['email'] == mensagem:

                mensagem = ''.join(i['mensagem'])

                if len(mensagem) > 4000:
                    for x in range(0, len(mensagem), 4000):
                        await query.message.answer(f'Histórico de mensagens com o usuário <b>{i["email"]}</b>\n\n{mensagem[x:x+4000]}')
                else:
                    await query.message.answer(f'Histórico de mensagens com o usuário <b>{i["email"]}</b>\n\n{mensagem}')

dp.register_callback_query_handler(lidar_com_callback)

@dp.message_handler()
async def mensagem_de_retorno(msg: types.Message):
    """Capturar a mensagem e enviá-la ao usuário correto"""

    with open('data/admins.json') as arquivo:
        admins = json.load(arquivo)

    flag = False
    for i in admins:
        if i['id_admin'] == msg.chat.id:
            flag = True

            with open('data/plaseholders.json') as arquivo2:
                placeholders = json.load(arquivo2)

            for j in placeholders:

                if j["id_admin"] == i['id_admin'] and j['id'] != None:
                    with open('data/data.json') as arquivo3:
                        usuarios = json.load(arquivo3)

                    for k in usuarios:
                        if k['id'] == j['id']:
                            k["mensagem"].append(f'<b>De:</b> {msg.text}\n')

                            with open(f'data/data.json', 'w') as arquivo4:
                                json.dump(usuarios, arquivo4, indent=3, ensure_ascii=False)

                    await bot.send_message(chat_id=str(j["id"]), text=msg.text)
                    break

                if j['id'] == None and j["id_admin"] == i['id_admin']:
                    await msg.answer('Para começar, selecione um usuário para o qual deseja enviar a mensagem. Ninguém está selecionado no momento')

    if not flag:
        with open('data/data.json') as arquivo3:
            usuarios = json.load(arquivo3)

        if usuarios:
            for k in usuarios:
                if k["id"] == msg.chat.id:
                    if k['id_admin'] == None:
                        k["mensagem"].append(f'<b>De:</b> {msg.text}\n')

                        with open(f'data/data.json', 'w') as arquivo4:
                            json.dump(usuarios, arquivo4, indent=3, ensure_ascii=False)

                        for z in admins:
                            await bot.send_message(str(z['id_admin']), f'<b>Nova mensagem</b>\npara: {msg.text}')

                        await msg.answer('Mensagem enviada.')
                    else:
                        await msg.answer('A mensagem que você enviar será recebida pelo administrador, e não pelo usuário. Vá para a guia "Conversar com Quem?" para verificar a quem a mensagem será enviada')

        else:
            with open('data/data.json', 'w') as arquivo4:
                json.dump([{
                    "id": msg.chat.id,
                    "email": msg.text,
                    "mensagem": [],
                    "id_admin": None
                }], arquivo4, indent=3, ensure_ascii=False)
            await msg.answer('Nenhuma mensagem enviada anteriormente. Vou considerar sua mensagem anterior como um e-mail do usuário')
    else:
        await msg.answer('A mensagem que você enviar será recebida pelo administrador e não pelo usuário. Vá para a guia "Conversar com Quem?" para verificar a quem a mensagem será enviada.')

if __name__ == "__main__":
    from aiogram import executor
    executor.start_polling(dp, skip_updates=True)
