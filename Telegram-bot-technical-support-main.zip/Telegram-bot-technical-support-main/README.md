# Telegram-bot-suporte técnico
Bot Telegram para implementação de suporte técnico aos usuários com possibilidade de conectar um número ilimitado de administradores.

O bot está usando o aiograma 2.25.1

Funcionalidade:
transferir clientes de um administrador para outro administrador, visualizar o histórico de correspondência com um usuário, alternar entre usuários, excluir um usuário.
